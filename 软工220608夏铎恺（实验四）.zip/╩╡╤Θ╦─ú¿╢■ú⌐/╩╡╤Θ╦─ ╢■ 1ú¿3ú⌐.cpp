﻿#include <iostream>
using namespace std;
void f(char* st, int i)
{
		st[i] = '\0';
	cout << st; // printf(“%s\n”,st);
	if (i > 1) f(st, i - 1);
}
void main()
{
	char st[] = "abcd";
	f(st, 4);
}
//补充完整，运行时输出为：abcdabcaba

